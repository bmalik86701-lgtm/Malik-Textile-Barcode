package com.maliktextile.barcode

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var printer: BluetoothDevice? = null
    private lateinit var status: TextView
    private lateinit var deviceSpinner: Spinner
    private lateinit var nameInput: EditText
    private lateinit var codeInput: EditText
    private lateinit var mrpInput: EditText
    private lateinit var priceInput: EditText
    private lateinit var qtyInput: EditText
    private var paired: List<BluetoothDevice> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestBtPermission()
        loadPaired()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 30, 28, 28)
            setBackgroundColor(Color.rgb(243,246,251))
        }
        scroll.addView(col)
        setContentView(scroll)

        val header = TextView(this).apply {
            text = "MALIK TEXTILE\\nBarcode Printer"
            textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(18,24,18,24); setBackgroundColor(Color.rgb(16,45,89))
        }
        col.addView(header, match())
        status = TextView(this).apply {
            text = "Printer not connected"; textSize = 14f
            setPadding(4,18,4,12); setTextColor(Color.DKGRAY)
        }
        col.addView(status)
        deviceSpinner = Spinner(this)
        col.addView(deviceSpinner, match())
        addButton(col, "Refresh Bluetooth Printers") { loadPaired() }
        addButton(col, "Connect Selected Printer") { connectSelected() }

        nameInput = field(col, "Product Name", "T-SHIRT")
        codeInput = field(col, "Barcode / Product Code", "")
        mrpInput = field(col, "MRP (₹)", "150")
        priceInput = field(col, "Selling Price (₹)", "140")
        qtyInput = field(col, "Number of Labels", "1")

        addButton(col, "PRINT LABELS  •  50 × 27 mm", true) { printLabels() }
        val note = TextView(this).apply {
            text = "Bluetooth POS-58 • CODE128 • 50×27mm label on 58mm roll\\nPair the printer in Android Bluetooth settings first."
            textSize = 12f; setTextColor(Color.DKGRAY); setPadding(4,20,4,8)
        }
        col.addView(note)
    }

    private fun match() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 }
    private fun field(parent: LinearLayout, label: String, hint: String): EditText {
        val t = TextView(this).apply { text = label; textSize = 13f; setTextColor(Color.DKGRAY) }
        parent.addView(t, match())
        val e = EditText(this).apply {
            this.hint = hint; textSize = 16f; singleLine = true
            setPadding(14,8,14,8); setBackgroundColor(Color.WHITE)
        }
        parent.addView(e, match())
        return e
    }
    private fun addButton(parent: LinearLayout, text: String, primary: Boolean = false, action: () -> Unit) {
        val b = Button(this).apply {
            this.text = text
            if (primary) setBackgroundColor(Color.rgb(21,88,192))
            if (primary) setTextColor(Color.WHITE)
            setOnClickListener { action() }
        }
        parent.addView(b, match())
    }

    private fun requestBtPermission() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 77)
        }
    }

    @Suppress("MissingPermission")
    private fun loadPaired() {
        try {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            if (adapter == null) { status.text = "This phone has no Bluetooth adapter"; return }
            if (!adapter.isEnabled) { status.text = "Turn on Bluetooth first"; return }
            paired = adapter.bondedDevices?.sortedBy { it.name ?: it.address }?.toList() ?: emptyList()
            val labels = if (paired.isEmpty()) listOf("No paired printer - pair POS-58 in Android Settings")
                         else paired.map { "${it.name ?: "Bluetooth device"}  (${it.address})" }
            deviceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
            status.text = "Found ${paired.size} paired Bluetooth device(s)"
        } catch (e: SecurityException) { status.text = "Allow Nearby Devices permission, then refresh" }
    }

    @Suppress("MissingPermission")
    private fun connectSelected() {
        if (paired.isEmpty()) { status.text = "Pair POS-58 in Android Bluetooth settings first"; return }
        val device = paired.getOrNull(deviceSpinner.selectedItemPosition) ?: return
        status.text = "Connecting to ${device.name}..."
        thread {
            try {
                socket?.close()
                val s = device.createRfcommSocketToServiceRecord(spp)
                s.connect()
                socket = s; printer = device
                runOnUiThread { status.text = "Connected: ${device.name}" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Connection failed. Pair POS-58 and retry. ${e.message ?: ""}" }
            }
        }
    }

    private fun printLabels() {
        val s = socket
        if (s == null || !s.isConnected) { status.text = "Connect POS-58 first"; return }
        val name = nameInput.text.toString().trim()
        val code = codeInput.text.toString().trim().ifBlank { "MT${System.currentTimeMillis()}" }
        val mrp = mrpInput.text.toString().trim()
        val price = priceInput.text.toString().trim()
        val qty = qtyInput.text.toString().toString().toIntOrNull()?.coerceIn(1,100) ?: 1
        if (name.isBlank() || price.isBlank()) { status.text = "Enter Product Name and Selling Price"; return }
        status.text = "Printing $qty label(s)..."
        thread {
            try {
                val out = s.outputStream
                repeat(qty) {
                    val bitmap = makeLabel(name, code, mrp, price)
                    out.write(byteArrayOf(0x1B, 0x40))
                    out.write(raster(bitmap))
                    out.write(byteArrayOf(0x1B, 0x64, 0x03))
                    out.flush()
                }
                runOnUiThread { status.text = "Print sent: $qty label(s)" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Print failed: ${e.message ?: "Bluetooth error"}" }
            }
        }
    }

    private fun makeLabel(name: String, code: String, mrp: String, price: String): Bitmap {
        // 58mm paper width at ~203dpi (8 dots/mm); 50x27mm label.
        val w = 464; val h = 216
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp); c.drawColor(Color.WHITE)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textAlign = Paint.Align.CENTER }
        val left = 16f // centered 50mm label, shifted 2mm left on 58mm paper
        val right = 416f
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f
        c.drawRect(left, 3f, right, 213f, p)
        p.style = Paint.Style.FILL; p.typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        p.textSize = 18f; c.drawText("MALIK TEXTILE", (left+right)/2, 27f, p)
        p.textSize = 17f; c.drawText(name.take(26), (left+right)/2, 49f, p)
        p.textAlign = Paint.Align.LEFT; p.textSize = 25f
        if (mrp.isNotBlank()) c.drawText("₹$mrp", left+32f, 82f, p)
        p.textAlign = Paint.Align.RIGHT; p.textSize = 42f
        c.drawText("₹$price", right-10f, 86f, p)
        if (mrp.isNotBlank()) {
            val strike = Paint().apply { color = Color.BLACK; strokeWidth = 2f }
            c.drawLine(left+28f, 72f, left+116f, 72f, strike)
        }
        try {
            val matrix = MultiFormatWriter().encode(code, BarcodeFormat.CODE_128, 340, 76)
            val bc = Bitmap.createBitmap(340, 76, Bitmap.Config.ARGB_8888)
            for (x in 0 until 340) for (y in 0 until 76)
                bc.setPixel(x,y, if (matrix[x,y]) Color.BLACK else Color.WHITE)
            c.drawBitmap(bc, null, RectF(left+30f, 101f, right-30f, 178f), null)
        } catch (_: Exception) { }
        p.textAlign = Paint.Align.CENTER; p.textSize = 15f
        c.drawText(code.take(32), (left+right)/2, 199f, p)
        return bmp
    }

    private fun raster(bitmap: Bitmap): ByteArray {
        val width = bitmap.width
        val height = bitmap.height
        val bytesPerRow = (width + 7) / 8
        val data = ByteArray(bytesPerRow * height)
        for (y in 0 until height) for (x in 0 until width) {
            val pixel = bitmap.getPixel(x,y)
            val lum = (Color.red(pixel)*299 + Color.green(pixel)*587 + Color.blue(pixel)*114)/1000
            if (lum < 160) {
                val idx = y * bytesPerRow + x/8
                data[idx] = (data[idx].toInt() or (0x80 shr (x%8))).toByte()
            }
        }
        val header = byteArrayOf(0x1D,0x76,0x30,0x00,
            (bytesPerRow and 0xFF).toByte(), ((bytesPerRow shr 8) and 0xFF).toByte(),
            (height and 0xFF).toByte(), ((height shr 8) and 0xFF).toByte())
        return header + data
    }

    override fun onDestroy() {
        try { socket?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
