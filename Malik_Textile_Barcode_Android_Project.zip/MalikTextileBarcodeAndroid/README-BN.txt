MALIK TEXTILE BARCODE PRINTER - ANDROID PROJECT

এই প্রজেক্টটি আপনার নিজের Android APK বানানোর Source Project।
Printer: Bluetooth POS-58 (Bluetooth Classic / SPP)
Label: 50 x 27 mm, 58mm roll width
Barcode: CODE128
Functions: product name, MRP, selling price, barcode, quantity, Bluetooth connect and print.

গুরুত্বপূর্ণ:
1) POS-58-কে Android Bluetooth Settings থেকে আগে Pair করুন।
2) এই অ্যাপ প্রথমবার Nearby Devices/Bluetooth permission চাইবে।
3) অ্যাপে paired printer select করে Connect করুন।
4) Product details দিয়ে PRINT LABELS চাপুন।
5) Printer firmware যদি standard ESC/POS SPP + GS v 0 raster command support করে, তবেই direct print হবে।
6) কিছু POS-58 clone printer proprietary command ব্যবহার করে; সে ক্ষেত্রে test print না হলে printer-এর exact Bluetooth protocol/ESC-POS support যাচাই করতে হবে।

APK Build:
এই ZIP-টি GitHub repository-তে upload করুন।
তারপর Actions tab > Build Malik Textile APK > Run workflow।
Build শেষ হলে Artifacts থেকে Malik-Textile-Barcode-APK download করুন।
এটি debug APK; নিজের ফোনে install করার সময় Android security confirmation দিতে হতে পারে।

এই পরিবেশে APK compile করে printer-এ বাস্তবে পরীক্ষা করা হয়নি। Source project-এ cloud build workflow আছে।
